CREATE TABLE stock_prices(
  ticker TEXT,
  dt DATE,
  open DOUBLE,
  high DOUBLE,
  low DOUBLE,
  close DOUBLE
);
