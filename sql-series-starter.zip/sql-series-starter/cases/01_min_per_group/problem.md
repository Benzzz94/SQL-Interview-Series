# Case 01 — Min per ticker (return the row; handle ties)

**Task:** For each `ticker`, return the row(s) whose `open` is the minimum in the dataset.  
**Output:** `ticker, dt, open, high, low, close` ordered by `ticker, dt`.  
**Edge cases:** ties (multiple rows with same minimum `open`).

